rm -r ~/.factom/ldb
rm -r ~/.factom/data
rm -r ~/.factom/logs
rm ~/.factom/fs_test.db
rm ~/.factom/bolt_my.db
rm ~/.factom/fct_test.db
rm ~/.factom/ldb.ver
rm ~/.factom/factoid_bolt.db
rm ~/.factom/factom-d.log
