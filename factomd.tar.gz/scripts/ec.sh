number=$RANDOM
echo "Make Chain Named " $number
echo "test" | fct mkchain -e $number e1 &
number=$RANDOM
echo "Make Chain Named " $number
echo "test" | fct mkchain -e $number e1 &
number=$RANDOM
echo "Make Chain Named " $number
echo "test" | fct mkchain -e $number e1 &
number=$RANDOM
echo "Make Chain Named " $number
echo "test" | fct mkchain -e $number e1 &

