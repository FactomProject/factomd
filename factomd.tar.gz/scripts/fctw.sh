#!/bin/bash

while true ;
do
	fctwallet
done
