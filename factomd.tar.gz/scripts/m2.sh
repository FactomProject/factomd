#!/usr/bin/env bash

while true ;
do
	scripts/multichains.sh
done