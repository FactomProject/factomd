#!/usr/bin/env bash
#import addresses
factom-cli  importaddress Fs2DNirmGDtnAZGXqca3XHkukTNMxoMGFFQxJA3bAjJnKzzsZBMH
factom-cli  importaddress Es3LB2YW9bpdWmMnNQYb31kyPzqnecsNqmg5W4K7FKp4UP6omRTa
factom-cli  importaddress Es2Zp56srDCV1QBFreSqYNSEkLSys2sj54L5qE3M88dWnoVL9sEf
factom-cli  importaddress Es38CboJYYSovciHHtigHiv9kkKf5uzAAQjBst5QYcgt9a4m6ywv
factom-cli  importaddress Es2aZZDjHdnnLzLWnDmNMRQFxTuRGsBsR7Gx96wBLNAWYQWoTFeH
factom-cli  importaddress Es3p1AND3WwwTNNNPHLNy6LC8RQTE9YUE2zPYvXHPFLz5siAwT1H
factom-cli  importaddress Es37igANtD8Z44pdXnNX4M5GJEsNLAk84MVVvrvnWRtBoacYmtdN
factom-cli  importaddress Es2Rf7iM6PdsqfYCo3D1tnAR65SkLENyWJG1deUzpRMQmbh9F3eG
factom-cli  importaddress Es4Mzp5ULbHw8eF4ZsxCRGFdhk8x2NbBEh1qor8aYoTxBmUP2TM4
factom-cli  importaddress Es2tsKCLkXNMFVMT5GxiEVQz6KXdConW65cU3YTJokAHxPyYdWpA
factom-cli  importaddress Es3e762q6TyqsyCtDai2RzzyUefWkoW3fdawyeK8CYfeYdhK1zz1
factom-cli  importaddress Es2eDGnHNi8sTGtMyQSZV7HQX6yJXH8pnDnruS99vSzCD3vJwJoo
factom-cli  importaddress Es3t4CtTPUuhBd41FB4BaVfH4Q2y7Qbs8xqk5MQ2x2KwR1r6eK2B
factom-cli  importaddress Es3FV5JhfSxBbgfVPBKoziU3VcxYq4hgiXNiC3d9RgMvEvNCm3Jj
factom-cli  importaddress Es3EfnjhS65agfy1cDoqUTxjicU3sL9cYxujwLzP1vnhHn9BjVvM
factom-cli  importaddress Es3PQb6fVpLV2FbjrtxQXGGK6x9NmRiiDzjxhZEMXsVzh9efX5Cs
factom-cli  importaddress Es2bSy4z5GFr4854fw6ZmQJM58xoYzuU7TfUt216ic7h4BQnGNqF
factom-cli  importaddress Es3Bevp66wUp5NotP5a9SB2sBLj18uMvb3sqeJRUaDveJsgjanmm
factom-cli  importaddress Es2azYxtCLskkvApoEMPAngqLXytpFyeVjikfLgundkQZPHTm31G
factom-cli  importaddress Es34frQyDvxQDPeo7ZRFUxQjhkfSECFYh8GzNuczAL5JDtuuBbzG
factom-cli  importaddress Es2hhDhFbWB1F2qGmhHZpgGX6WqYASELApeLpFAecrgaRUAAZwRd

#assign public keys to variables
ec[0]=EC1nje9iEd4k3hzHad4Qty7fAxKdji9Ep4ZjnRiTAcSrEDL1drU4
ec[1]=EC1qYbSLcGdLsbEkEMD1X9XqTff89Dc3mB94o6S55eAsahtGBQfK
ec[2]=EC1zpfdA5BjH6ixoYsu9KmYDrjDkqp1dX17nrgnWQ9Vsckh21Bbo
ec[3]=EC26nwbLvZk7h2U7C9V6hDKyuAHVz9LB9mwFCKYdaAdCd6zBf6kH
ec[4]=EC28pzmdcSg82ZyHRRrRukDxbCXAD4E6ftt1EsufmqVXaKTuWpU2
ec[5]=EC2DKSYyRcNWf7RS963VFYgMExoHRYLHVeCfQ9PGPmNzwrcmgm2r
ec[6]=EC2MAKZyVMuPdFEXEVd3bZMzJvb9xc6e3y5x11wbUczZzxnLNxuz
ec[7]=EC2N8ACTibRrHWDfp69sgNgtg6QG3GNUnB2HLtYG4iWNEZWrna5a
ec[8]=EC2aP6FUr1Ka9qfnZQSA5jbNGNaZeQjqnMmdyvJiBKXDx4eyip4P
ec[9]=EC2bGXjgzFdxj1PpoHekFadN4mjqPDaJeTcGS2tW1KVAeh7BYVb6
ec[10]=EC2dmFatZhymujjfRTvoesTNgKES1AqTADBMD1JE1cu2CmqFRVbF
ec[11]=EC2enVcf1ZV3vE1rTA7muepnM44LBhJS97j9eaeyDVuAN2SW5VJk
ec[12]=EC2kcjomA1sRmtuNdEEBwmR5PpZQfj2dEXJFx9gyTXeAsr2v3smh
ec[13]=EC2yuMHdCn1V1j2vHEc4gCMcQ8nR7TiSpMmL1zZNqejpZaaJ1WSB
ec[14]=EC31ASJ7P32tBrV54FjJHY6fZgQJT1t4gZRzz3fMszSNNzLuyhme
ec[15]=EC33dwXXiMGxCeTBVBcZzHF8QM4ge7UHnXAygmbVXAn1cWUsHn4X
ec[16]=EC37iMMmjtjqdofpeQDkP9XPQkinLC66JW22j7RVSsQv7oBMuC8W
ec[17]=EC3C1hhyojkBTQEtfti7vAueRJWtrLUCatQLPdzFSp5xsc8yPk4q
ec[18]=EC3fTo4Vj4nU3WCJcTFEes9Qdy21G8CRGVSMwSeBKtHVpaWEk1W8
ec[19]=EC3hNsEBBzFvf58pw1omVgrBobA6S4kEE4656uqdfk4ex7811vwr


#transfer funds to each of the entry credit address
for ((i=0; i < 20; i++)); do
echo $i
factom-cli newtx t1
factom-cli addtxinput t1 FA3EPZYqodgyEGXNMbiZKE5TS2x2J9wF8J9MvPZb52iGR78xMgCb 10
factom-cli addtxecoutput t1 ${ec[i]} 10

factom-cli addtxfee t1 FA3EPZYqodgyEGXNMbiZKE5TS2x2J9wF8J9MvPZb52iGR78xMgCb
factom-cli signtx t1
factom-cli sendtx t1
factom-cli listaddresses
echo remove t1
factom-cli rmtx t1
sleep .2s
done


#create chain with each of the entry credit address
for i in $(seq 20); do
echo ${ec[i]}
factom-cli addchain -e testing$i -e factom ${ec[i]} < ~/go/src/github.com/FactomProject/factomd/scripts/data.txt
sleep .2s
done



#assign chainid to variables
ChainID[1]=5132d9a8895a3b07d9ee61b856d860029f95947f8b504a1065c90bfdf5de133d
ChainID[2]=85d578a3a13999e261f06131235b3549b0d136755d52820e6c8ce14019334900
ChainID[3]=292024e2ae4c36acfb9650e6b145f6b60486c118322ceb1dad58d851276715d7
ChainID[4]=8f0657e56d8c860aed79f1d965df1ee8a42010fd918390c11394cb6ea39510a0
ChainID[5]=d70bc802a0d88df358048c731075a2ee3186d3f9c16c0ef66a61c37b56855712
ChainID[6]=991c54538c1a26ca564589327a9087c62a74596d013fbd24a1cb07911b9652bc
ChainID[7]=64eefedf8911c56db0bec825deea62d9dd4252b9aeb59adceeeee07132f35be4
ChainID[8]=84b6b414704fb3cff43304f11a4609dc919b9142c33b9ab1124e7fbe7462298c
ChainID[9]=1b869d24cf0709ea93a04c23c6aea239f3c35ce8a3e51fd6767a6181d37e3e1a
ChainID[10]=085cecb8874d10e74987f7262465601421e15abf85410c46b175dc7c053731c7
ChainID[11]=5a16f703ffd83ce4816214eb9cff79dd7ce650a6fa393273cbd824ed036dfbbe
ChainID[12]=868aa9e374e014cda9c293f1cb4a9f16dc3b28abed1d2141cbc5545bbc3e3e31
ChainID[13]=2de808ccfb8db7bb44a8e5722b6655b589079dd9a8ae0fbee2da3370d5d9e13a
ChainID[14]=b69469af5a875cfd50786827e92171a84232bd7a198fa29234ac931e40a342c3
ChainID[15]=58bf7850ef6afe6ef313718afb20429b3f6eb094fe297de5cdf8d08d4ebd3c86
ChainID[16]=33d3f40829af1dccf7798a55f3074855dba20a27a1b780cb32f1df849ef94757
ChainID[17]=a7576d1b7cae66a083fcd3e2117f35f9b6b217a0c8df6aaa53278215fe70a07f
ChainID[18]=b4e0ec762c2372e028e0838542a8134f804e09721fd4460315b03a36e8303489
ChainID[19]=f37f3789fdf3c9c73dabf7687cfdb730532c0cce2cebbb962739231c06cdf93f
ChainID[20]=bbaa38fbfb0ba18456e631df41b488662d69c84f4f55463f5ad28121a939f678

#factom-cli addentry to each of the chains
for j in $(seq 1000); do
for i in $(seq 20); do
echo "---------------------------------"
echo "Getting all entries before adding the entry $i" 
echo "---------------------------------"
factom-cli get allentries ${ChainID[i]}
echo "Making entries into chain $i" 
echo "---------------------------------"
factom-cli addentry -c ${ChainID[i]} ${ec[i]} < ~/go/src/github.com/FactomProject/factomd/scripts/data.txt
echo "---------------------------------"
echo "Getting all entries after adding the entry $i" 
factom-cli get allentries ${ChainID[i]}
echo "---------------------------------"
sleep .1s
done
echo "current head details"
echo "---------------------------------"
factom-cli get head
sleep 10s
done

