#!/usr/bin/env bash
factom-cli importaddress b Fs1fbEjDxWhXasmnp6R7DMFRo1oQBCJaa61hqkQQqhVGE8oJWKFE
factom-cli generateaddress fct b1
factom-cli generateaddress fct b2
factom-cli generateaddress fct b3
factom-cli generateaddress fct b4
factom-cli generateaddress fct b5
factom-cli generateaddress fct b6
factom-cli generateaddress fct b7
factom-cli generateaddress fct b8
factom-cli generateaddress fct b9

factom-cli generateaddress ec e1
factom-cli generateaddress ec e2
factom-cli generateaddress ec e3
factom-cli generateaddress ec e4
factom-cli generateaddress ec e5
factom-cli generateaddress ec e6
factom-cli generateaddress ec e7
factom-cli generateaddress ec e8
factom-cli generateaddress ec e9

fct balances
