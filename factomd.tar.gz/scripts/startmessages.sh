#!/usr/bin/env bash
reset
tail -f out.txt | grep \\*\\*\\* $@