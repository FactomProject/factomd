fct deletetransaction t
fct newtransaction t
fct addinput t factoid-wallet-address-name01 60
fct addoutput t b1 30
fct addoutput t b2 30
fct addfee t factoid-wallet-address-name01
fct sign t
fct submit t



fct deletetransaction t
fct newtransaction t
fct addinput t b1 6.079992
fct addecoutput t e1 6
fct addinput t b2 0.179992
fct addecoutput -r t factom.michaeljbeam.me .1
fct addfee t factoid-wallet-address-name01
fct sign t
fct submit t

